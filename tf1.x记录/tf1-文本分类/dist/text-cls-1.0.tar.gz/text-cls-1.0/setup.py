import setuptools
setuptools.setup(
    name='text-cls',
    version='1.0',
    packages=['code'],
    install_requires=[]
)
