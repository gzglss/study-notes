import setuptools
setuptools.setup(
    name='text-cls-lexicon',
    version='1.0',
    packages=['code'],
    install_requires=[]
)
