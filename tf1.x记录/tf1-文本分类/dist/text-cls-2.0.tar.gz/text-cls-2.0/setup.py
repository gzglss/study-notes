import setuptools
setuptools.setup(
    name='text-cls',
    version='2.0',
    packages=['code'],
    install_requires=[]
)
